AI動漫格鬥遊戲 0.296 版本 — Capacitor + GitHub Actions 雲端自動編譯 APK 教學
============================================================================

本機完全不用安裝 Android Studio、Java 或任何開發工具，只要上傳到 GitHub 就能自動產出 .apk！

【使用步驟（約 3 分鐘）】
1. 將本 ZIP 壓縮檔完整解壓縮到一個資料夾。
   ※ 注意：裡面有一個隱藏資料夾「.github」，上傳時務必一起包含（Windows 可在檔案總管勾選「顯示隱藏的項目」確認）。

2. 前往 https://github.com 登入帳號，點右上角「+」→「New repository」建立一個新倉庫（公開 Public 或私人 Private 都可以）。

3. 將解壓縮後的全部檔案上傳到這個 GitHub 倉庫的 main 分支：
   - 方式 A（網頁上傳）：點「uploading an existing file」，把整個資料夾內的所有檔案（包含 .github、scripts、www、package.json、capacitor.config.json）拖進去後按 Commit changes。
   - 方式 B（Git 指令）：
     git init
     git add .
     git commit -m "init v0.296"
     git branch -M main
     git remote add origin <你的倉庫網址>
     git push -u origin main

4. 點選倉庫上方的「Actions」分頁：
   - 會看到「Build Android APK」正在自動執行（若沒自動跑，可點左側 Build Android APK → 右側 Run workflow 手動啟動）。
   - 等待約 2～3 分鐘變成綠色勾勾 ✅。
   - 點進該次執行紀錄，拉到頁面最下方的「Artifacts」區塊，點擊「AI動漫格鬥遊戲0.296版本-APK」即可下載 .apk 檔！

5. 將下載下來的 .apk 傳到 Android 手機／平板點擊安裝（系統詢問時允許「安裝未知來源應用程式」即可），開啟即為橫向全螢幕離線 App。

【未來更新遊戲版本超簡單】
之後只要拿到新版本的 HTML 遊戲檔，把它改名為 index.html 覆蓋掉 www/index.html，再推送到 GitHub，雲端就會自動重新編譯出新版 APK！
