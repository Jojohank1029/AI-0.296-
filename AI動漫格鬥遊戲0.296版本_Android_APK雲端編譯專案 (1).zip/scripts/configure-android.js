const fs = require('fs');
const path = require('path');

// 1) Lock MainActivity to sensorLandscape for optimal fighting-game controls
const manifestPath = path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(manifestPath)) {
  let xml = fs.readFileSync(manifestPath, 'utf8');
  if (!xml.includes('android:screenOrientation')) {
    xml = xml.replace(
      /<activity([^>]*android:name="\.MainActivity"[^>]*)>/,
      '<activity$1 android:screenOrientation="sensorLandscape">'
    );
    fs.writeFileSync(manifestPath, xml, 'utf8');
    console.log('Patched AndroidManifest.xml -> sensorLandscape');
  }
}

// 2) Copy pixel-art icon into Android mipmap folders
const iconSrc = path.join('www', 'icons', 'icon-512.png');
const resDir = path.join('android', 'app', 'src', 'main', 'res');
if (fs.existsSync(iconSrc) && fs.existsSync(resDir)) {
  const dirs = fs.readdirSync(resDir).filter(d => d.startsWith('mipmap-') && !d.includes('anydpi'));
  for (const d of dirs) {
    const dirPath = path.join(resDir, d);
    for (const targetName of ['ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png']) {
      const target = path.join(dirPath, targetName);
      if (fs.existsSync(target)) {
        fs.copyFileSync(iconSrc, target);
      }
    }
  }
  console.log('Copied pixel-art launcher icons into:', dirs.join(', '));
}
